<?php

$time = time();

return [
    'user' => [
        'user_id' => 1,
        'name'    => 'John Doe',
    ],
];
